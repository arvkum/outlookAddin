﻿using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Windows.Shapes;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.XPath;

namespace OutlookAddIn1
{

    public class Helpers
    {


        //public static HttpClient GetHttpClient(string connectionString, string clientId, string redirectUrl, string version = "v9.2")
        public static HttpClient GetHttpClient(string url, string username, string password, string clientId, string redirectUrl, string version)
        {

            try
            {
                HttpMessageHandler messageHandler = new OAuthMessageHandler(url, clientId, redirectUrl, username, password,
                                new HttpClientHandler());

                HttpClient httpClient = new HttpClient(messageHandler)
                {
                    BaseAddress = new Uri(string.Format("{0}/api/data/{1}/", url, version)),

                    Timeout = new TimeSpan(0, 2, 0)  //2 minutes
                };

                return httpClient;
            }
            catch (Exception)
            {
                throw;
            }
        }


        /// <summary>
        /// Method used to get a value from the connection string
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="parameter"></param>
        /// <returns>The value from the connection string that matches the parameter key value</returns>
        public static string GetParameterValueFromConnectionString(string connectionString, string parameter)
        {
            try
            {
                return connectionString.Split(';').Where(s => s.Trim().StartsWith(parameter)).FirstOrDefault().Split('=')[1];
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        // CrmServiceClient is not used because got errors then it was replaced by GetHttpClient method - to be investigated further later
        public static CrmServiceClient Connect(string name)
        {
            CrmServiceClient service = null;

            //You can specify connection information in cds/App.config to run this sample without the login dialog
            if (string.IsNullOrEmpty(GetConnectionStringFromAppConfig("Connect")))
            {
                // Failed to find a connection string
            }
            else
            {
                // Try to create via connection string. 

                service = new CrmServiceClient(GetConnectionStringFromAppConfig("Connect"));
            }

            return service;

        }

        private static string GetConnectionStringFromAppConfig(string name)
        {
            //Verify cds/App.config contains a valid connection string with the name.
            try
            {
                return ConfigurationManager.ConnectionStrings[name].ConnectionString;
            }
            catch (System.Exception)
            {
                Console.WriteLine("You can set connection data in cds/App.config before running this sample. - Switching to Interactive Mode");
                return string.Empty;
            }
        }

        public static string GetCustomSetting(string key, string section)
        {

            NameValueCollection settings = ConfigurationManager.GetSection("customAppSettingsGroup/" + section) as NameValueCollection;
            try
            {
                return settings[key];
            }
            catch (Exception)
            {
                return string.Empty;
            }


        }



        public static string[] GetAutoApprovedEngineersList(string autoApprovedEngineersList)
        {

            try
            {
                string[] autoApprovedEngineers = autoApprovedEngineersList.Split(';');
                return autoApprovedEngineers;
            }
            catch (Exception)
            {
                return null;
            }
        }


        public static void XmlUserSettingsWriter(UserSettings obj,string directory,  string xmlFileName)
        {

            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            XmlSerializer sr = new XmlSerializer(obj.GetType());
            TextWriter writer = new StreamWriter(directory + @"\" + xmlFileName);
            sr.Serialize(writer, obj);
            writer.Close();


        }

        public static UserSettings XmlUserSettingsReader(string xmlFileName)
        {

            XmlSerializer xs = new XmlSerializer(typeof(UserSettings));
            FileStream reader = new FileStream(xmlFileName, FileMode.Open, FileAccess.Read, FileShare.Read);
            UserSettings obj = (UserSettings)xs.Deserialize(reader);
            reader.Close();
            return obj;

        }

    }

}