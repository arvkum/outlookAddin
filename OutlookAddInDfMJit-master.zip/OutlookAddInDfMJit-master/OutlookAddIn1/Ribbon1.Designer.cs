﻿namespace OutlookAddIn1
{
    partial class Ribbon1 : Microsoft.Office.Tools.Ribbon.RibbonBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        public Ribbon1()
            : base(Globals.Factory.GetRibbonFactory())
        {
            InitializeComponent();
        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tab1 = this.Factory.CreateRibbonTab();
            this.group1 = this.Factory.CreateRibbonGroup();
            this.retrieve = this.Factory.CreateRibbonButton();
            this.autoApprovedEngineersEditBox = this.Factory.CreateRibbonEditBox();
            this.folderEditBox = this.Factory.CreateRibbonEditBox();
            this.save = this.Factory.CreateRibbonButton();
            this.usernameEditBox = this.Factory.CreateRibbonEditBox();
            this.group2 = this.Factory.CreateRibbonGroup();
            this.openLogFile = this.Factory.CreateRibbonButton();
            this.deleteLogFile = this.Factory.CreateRibbonButton();
            this.openUserSettingsXml = this.Factory.CreateRibbonButton();
            this.tab1.SuspendLayout();
            this.group1.SuspendLayout();
            this.group2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tab1
            // 
            this.tab1.ControlId.ControlIdType = Microsoft.Office.Tools.Ribbon.RibbonControlIdType.Office;
            this.tab1.Groups.Add(this.group1);
            this.tab1.Groups.Add(this.group2);
            this.tab1.Label = "TabAddIns";
            this.tab1.Name = "tab1";
            // 
            // group1
            // 
            this.group1.Items.Add(this.retrieve);
            this.group1.Items.Add(this.autoApprovedEngineersEditBox);
            this.group1.Items.Add(this.folderEditBox);
            this.group1.Items.Add(this.save);
            this.group1.Items.Add(this.usernameEditBox);
            this.group1.Label = "User Settings - DfM Jit Approver";
            this.group1.Name = "group1";
            // 
            // retrieve
            // 
            this.retrieve.Label = "Retrieve";
            this.retrieve.Name = "retrieve";
            this.retrieve.ScreenTip = "Retrieve current user settings from AppData/Local/Microsoft_Corporation";
            this.retrieve.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.retrieve_Click);
            // 
            // autoApprovedEngineersEditBox
            // 
            this.autoApprovedEngineersEditBox.Image = global::OutlookAddIn1.Properties.Resources.authorizedEngineers;
            this.autoApprovedEngineersEditBox.Label = "Approved Engineers";
            this.autoApprovedEngineersEditBox.Name = "autoApprovedEngineersEditBox";
            this.autoApprovedEngineersEditBox.ScreenTip = "Enter list of jit requestor you want to approve";
            this.autoApprovedEngineersEditBox.ShowImage = true;
            this.autoApprovedEngineersEditBox.SuperTip = "Enter the list of your colleagues whom you want to automate the DfM Jit approval," +
    " separated by semicolon.  Names should be added exactly like verified in MS Team" +
    "s for example.";
            this.autoApprovedEngineersEditBox.Text = null;
            // 
            // folderEditBox
            // 
            this.folderEditBox.Image = global::OutlookAddIn1.Properties.Resources.outlook_mail_icon;
            this.folderEditBox.Label = "folder";
            this.folderEditBox.Name = "folderEditBox";
            this.folderEditBox.ScreenTip = "Outlook e-mail folder";
            this.folderEditBox.ShowImage = true;
            this.folderEditBox.SuperTip = "Enter your Outlook e-mail folder name where incoming DfM Jit e-mails are received" +
    "";
            this.folderEditBox.Text = null;
            // 
            // save
            // 
            this.save.Label = "Save";
            this.save.Name = "save";
            this.save.ScreenTip = "Save User Settings";
            this.save.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.save_Click);
            // 
            // usernameEditBox
            // 
            this.usernameEditBox.Image = global::OutlookAddIn1.Properties.Resources.login;
            this.usernameEditBox.Label = "username";
            this.usernameEditBox.Name = "usernameEditBox";
            this.usernameEditBox.ScreenTip = "your Microsoft account";
            this.usernameEditBox.ShowImage = true;
            this.usernameEditBox.SuperTip = "Enter your Microsoft e-mail account <alias>@microsoft.com to login into onesuppor" +
    "t.crm.dynamics.com";
            this.usernameEditBox.Text = null;
            // 
            // group2
            // 
            this.group2.Items.Add(this.openLogFile);
            this.group2.Items.Add(this.deleteLogFile);
            this.group2.Items.Add(this.openUserSettingsXml);
            this.group2.Label = "Application files - DfM Jit Approver";
            this.group2.Name = "group2";
            // 
            // openLogFile
            // 
            this.openLogFile.Label = "Open log file";
            this.openLogFile.Name = "openLogFile";
            this.openLogFile.ScreenTip = "open C:\\Users\\<yourUser>\\AppData\\Local\\Temp\\outlookAddinDfMJitApproval.log";
            this.openLogFile.SuperTip = "Log file contains execution logs of DfM jit approvals executed by this Add-In";
            this.openLogFile.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.openLogFile_Click);
            // 
            // deleteLogFile
            // 
            this.deleteLogFile.Label = "Delete log file";
            this.deleteLogFile.Name = "deleteLogFile";
            this.deleteLogFile.ScreenTip = "Delete C:\\Users\\<yourUser>\\AppData\\Local\\Temp\\outlookAddinDfMJitApproval.log";
            this.deleteLogFile.SuperTip = "Delete log file content to save disk space in your machine ";
            this.deleteLogFile.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.deleteLogFile_Click);
            // 
            // openUserSettingsXml
            // 
            this.openUserSettingsXml.Label = "Open user settings xml";
            this.openUserSettingsXml.Name = "openUserSettingsXml";
            this.openUserSettingsXml.ScreenTip = "Open User Settings xml file folder";
            this.openUserSettingsXml.SuperTip = "User Settings xml file contains User Settings: Approved Engineers, folder, userna" +
    "me. You can edit settings directly from xml file.";
            this.openUserSettingsXml.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.openUserSettingsXml_Click);
            // 
            // Ribbon1
            // 
            this.Name = "Ribbon1";
            this.RibbonType = "Microsoft.Outlook.Explorer";
            this.Tabs.Add(this.tab1);
            this.Load += new Microsoft.Office.Tools.Ribbon.RibbonUIEventHandler(this.Ribbon1_Load);
            this.tab1.ResumeLayout(false);
            this.tab1.PerformLayout();
            this.group1.ResumeLayout(false);
            this.group1.PerformLayout();
            this.group2.ResumeLayout(false);
            this.group2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal Microsoft.Office.Tools.Ribbon.RibbonTab tab1;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup group1;
        internal Microsoft.Office.Tools.Ribbon.RibbonEditBox autoApprovedEngineersEditBox;
        internal Microsoft.Office.Tools.Ribbon.RibbonEditBox folderEditBox;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton retrieve;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton save;
        internal Microsoft.Office.Tools.Ribbon.RibbonEditBox usernameEditBox;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup group2;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton openLogFile;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton deleteLogFile;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton openUserSettingsXml;
    }

    partial class ThisRibbonCollection
    {
        internal Ribbon1 Ribbon1
        {
            get { return this.GetRibbon<Ribbon1>(); }
        }
    }
}
