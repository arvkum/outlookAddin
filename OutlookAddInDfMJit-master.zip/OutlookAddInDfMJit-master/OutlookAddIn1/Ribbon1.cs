﻿using Microsoft.Office.Tools.Ribbon;
using OutlookAddIn1.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.IO;
using System.Windows;
using System.Configuration;


namespace OutlookAddIn1
{
    public partial class Ribbon1
    {


        
        private void Ribbon1_Load(object sender, RibbonUIEventArgs e)
        {

        }


        private void retrieve_Click(object sender, RibbonControlEventArgs e)
        {

            try
            {

                string directoryUserSettings = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Microsoft_Corporation";
                string userSettingsFileName = "outlookAddinDfMJitUserSettings.xml";
                string userSettingsFile = directoryUserSettings + @"\" + userSettingsFileName;

                if (File.Exists(userSettingsFile))
                {
                    UserSettings data = Helpers.XmlUserSettingsReader(userSettingsFile);
                    this.usernameEditBox.Text = data.Username;
                    this.folderEditBox.Text = data.Folder;
                    this.autoApprovedEngineersEditBox.Text = data.AutoApprovedEngineers;

                    MessageBox.Show("Current data stored in User Settings file: " + Environment.NewLine
                                    + userSettingsFile + Environment.NewLine + Environment.NewLine
                                    + "Approved Engineers: " + data.AutoApprovedEngineers + Environment.NewLine
                                    + "Folder: " + data.Folder + Environment.NewLine
                                    + "Username: " + data.Username + Environment.NewLine, "DfM Jit - Retrieve User Settings");
                }
                else
                {
                    MessageBox.Show("There is no user settings xml file yet. You must save your personal settings first", "DfM Jit - Retrieve User Settings");
                }
            }
            catch(Exception ex) 
            {
                MessageBox.Show("Error " + ex.ToString(), "DfM Jit - Retrieve User Settings");

            }
        }

        private void save_Click(object sender, RibbonControlEventArgs e)
        {

      


            try
            {
                //User Settings ->  Eg.: C:\Users\<user>\AppData\Local\Microsoft_Corporation\outlookAddinDfMJitUserSettings.xml
                string directoryUserSettings = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Microsoft_Corporation";
                string userSettingsFileName = "outlookAddinDfMJitUserSettings.xml";

                UserSettings data = new UserSettings();
                    data.Username = this.usernameEditBox.Text;
                    data.Folder = this.folderEditBox.Text;
                    data.AutoApprovedEngineers = this.autoApprovedEngineersEditBox.Text;

                    Helpers.XmlUserSettingsWriter(data, directoryUserSettings, userSettingsFileName);

                    MessageBox.Show("User settings successfully saved into file " + directoryUserSettings + userSettingsFileName
                         + Environment.NewLine + "If you are editing folder name, restart Outlook to apply the change"
                        , "DfM Jit - Save User Settings");


            }
            catch (Exception ex)
            {

                MessageBox.Show("Error " + ex.ToString(), "DfM Jit - Save User Settings");
            }
        }

        private void openLogFile_Click(object sender, RibbonControlEventArgs e)
        {
            try 
            {
                //Log -> Eg.:  C:\Users\<user>\AppData\Local\Temp\outlookAddinDfMJitApproval.log
                string logFile = System.IO.Path.GetTempPath() + @"outlookAddinDfMJitApproval.log";

                System.Diagnostics.Process.Start(logFile);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex.ToString(), "DfM Jit - Open Log File");
            }

        }

        private void deleteLogFile_Click(object sender, RibbonControlEventArgs e)
        {

            try
            {
                //Log -> Eg.:  C:\Users\<user>\AppData\Local\Temp\outlookAddinDfMJitApproval.log
                string logFile = System.IO.Path.GetTempPath() + @"outlookAddinDfMJitApproval.log";

                if (File.Exists(logFile))
                {
                    File.Delete(logFile);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex.ToString(), "DfM Jit - Delete Log File");
            }
        }

        private void openUserSettingsXml_Click(object sender, RibbonControlEventArgs e)
        {

            try
            {
                //User Settings ->  Eg.: C:\Users\<user>\AppData\Local\Microsoft_Corporation\outlookAddinDfMJitUserSettings.xml
                string directoryUserSettings = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Microsoft_Corporation";
                string userSettingsFileName = "outlookAddinDfMJitUserSettings.xml";
                string userSettingsFile = directoryUserSettings + @"\" + userSettingsFileName;
         
                System.Diagnostics.Process.Start("explorer.exe", directoryUserSettings);
            }
            catch  (Exception ex)
            {
                MessageBox.Show("Error " + ex.ToString(), "DfM Jit - Open User Settings xml file");
            }   
        }
    }
}
