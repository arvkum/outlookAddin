﻿using Newtonsoft.Json.Linq;
using System;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Forms;
using Exception = System.Exception;
using MessageBox = System.Windows.MessageBox;
using Outlook = Microsoft.Office.Interop.Outlook;
using System.Collections;
using Microsoft.Office.Interop.Outlook;

namespace OutlookAddIn1
{
    public partial class ThisAddIn
    {


        Outlook.NameSpace outlookNameSpace;
        Outlook.MAPIFolder inbox;
        Outlook.Items items;


        string folder = "";

        //User Settings ->  Eg.: C:\Users\roilidio\AppData\Local\Microsoft_Corporation\outlookAddinDfMJitUserSettings.xml
        string directoryUserSettings = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Microsoft_Corporation";
        string userSettingsFileName = "outlookAddinDfMJitUserSettings.xml";
        //string username = "";

        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            //// load user settings path in app.config, to retrieve path in other classes.
            //Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.PerUserRoamingAndLocal);
            //config.AppSettings.Settings.Add("directoryUserSettings", directoryUserSettings);
            //config.AppSettings.Settings.Add("userSettingsFile", userSettingsFileName);
            //config.Save(ConfigurationSaveMode.Minimal);

            outlookNameSpace = this.Application.GetNamespace("MAPI");
            inbox = outlookNameSpace.GetDefaultFolder(
                    Microsoft.Office.Interop.Outlook.
                    OlDefaultFolders.olFolderInbox);

            //// retrieve current Outlook account - account name will be used to login into CRM 
            //IEnumerator accounts = outlookNameSpace.Accounts.GetEnumerator();
            //while (accounts.MoveNext())
            //{
            //    Account account = (Account)accounts.Current;
            //    //username = account.DisplayName.ToString(); //
            //    username = account.SmtpAddress.ToString(); 
            //} //-> didn't work because it returns name like roberto.ilidio@microsoft.com instead of roilidio@microsoft.com which is required for login Hint in Dynamics authentication



            string userSettingsFile = directoryUserSettings + @"\" + userSettingsFileName;


            if (File.Exists(userSettingsFile))
            {
                UserSettings data = Helpers.XmlUserSettingsReader(userSettingsFile);
                folder = data.Folder;
                try
                {
                    items = inbox.Folders[folder].Items;
                    items.ItemAdd +=
                        new Outlook.ItemsEvents_ItemAddEventHandler(items_ItemAdd);
                }
                catch (Exception ex)
                {

                    MessageBox.Show("Error trying to add logic to incoming emails for Outlook folder " + folder +
                        ", probably because the folder doesn't exist or is not a subfolder of inbox."
                        + Environment.NewLine + "Check for any typo in the folder name defined in User Settings and try again."
                         + Environment.NewLine + "Exception: "
                          + Environment.NewLine + ex.ToString(), "DfM Jit Approver Outlook Add-In");
                }

            }
            else
            {
                MessageBox.Show("You have installed DfM Jit Approver Outlook Add-In. " +
                    "Note that you must define your user settings to make it work.  " + Environment.NewLine +
                    "Save your user settings in the Add-Ins Outlook ribbon tab and restart Outlook", "DfM Jit Approver Outlook Add-In");
            }

        }

        void items_ItemAdd(object Item)
        {

            #region App main logic

            //Log -> Eg.:  C:\Users\<user>\AppData\Local\Temp\outlookAddinDfMJitApproval.log
            string logFile = System.IO.Path.GetTempPath() + @"outlookAddinDfMJitApproval.log";
            string userSettingsFile = directoryUserSettings + @"\" + userSettingsFileName;


            // User Settings

            string autoApprovedEngineersString = "";
            string[] autoApprovedEngineers = new string[] { };

            // application configurations - app.config
            string senderFilter = "";
            string subjectFilter = Helpers.GetCustomSetting("subjectFilter", "generalSettings");

            //These sample application registration values are available for all online instances.
            //You can use these while running sample code, but you should get your own for your own apps
            string clientId = "51f81489-12ee-4a9e-aaae-a2591f45987d";
            string redirectUrl = "app://58145B91-0C36-4500-8554-080854F2AC97";


            string dfmUrl = "onesupport.crm.dynamics.com";
            string eudfmUrl = "eudfm.crm4.dynamics.com";

            string url = "";
            string version = "v9.2"; // /api/data/v9.2/
            string username = ""; //Helpers.GetParameterValueFromConnectionString(connectionString, "Username");
            string password = "";//Helpers.GetParameterValueFromConnectionString(connectionString, "Password"); //empty
            string appendLog = "";

            try
            {

                Outlook.MailItem mail = (Outlook.MailItem)Item;
                if (Item != null)
                {

                    // Retrieving User Settings from xml
                    if (File.Exists(userSettingsFile))
                    {
                        UserSettings data = Helpers.XmlUserSettingsReader(userSettingsFile);
                        username = data.Username;
                        autoApprovedEngineersString = data.AutoApprovedEngineers;
                        autoApprovedEngineers = Helpers.GetAutoApprovedEngineersList(autoApprovedEngineersString);

                        //there are optional User Settings senderFilter and subjectFilter. If are empty/null, hence default value from app.config is used.
                        if (!string.IsNullOrEmpty(data.SenderFilter))
                        {
                            // User settings xml file
                            senderFilter = data.SenderFilter;
                        }
                        else
                        {
                            // default value - app.config
                            senderFilter = Helpers.GetCustomSetting("senderFilter", "generalSettings");
                        }

                        if (!string.IsNullOrEmpty(data.SubjectFilter))
                        {
                            subjectFilter = data.SubjectFilter;
                        }
                        else
                        {
                            subjectFilter = Helpers.GetCustomSetting("subjectFilter", "generalSettings");
                        }

                    }
                    else
                    {
                        MessageBox.Show("There is a DfM Jit email notification incoming into your Outlook e-mail inbox but " +
                            "there is no user settings configured for this Add-In yet. Hence DfM Jit Approval Outlook Add-In won't approve any jit " + Environment.NewLine +
                            "Save your user settings in the Add-In Outlook Ribbon tab", "DfM Jit Approver Outlook Add-In");
                    }

                    //if (mail.MessageClass == "IPM.Note" &&  mail.Sender.Address.Contains(senderFilter) && mail.Subject.Contains(subjectFilter))
                    if (mail.MessageClass == "IPM.Note" && mail.Subject.Contains(subjectFilter))  // temp -  debug propose     
                    {




                        //// move DfM Jit incoming email from Inbox to folder (defined in user settings)
                        //if (!string.IsNullOrEmpty(folder))
                        //{
                        //    try
                        //    {
                        //        mail.Move(inbox.Folders[folder]);
                        //    }
                        //    catch (Exception ex)
                        //    {
                        //        MessageBox.Show("Error moving DfM Jit email from inbox to folder" + Environment.NewLine +
                        //            "Retrieve your user settings in the Add-In Outlook Ribbon tab to confirm if there is no typo" + Environment.NewLine +
                        //            "Exception: " + ex.Message.ToString());
                        //        throw;
                        //    }

                        //}

                        // if Engineer's names from auto approved list is in the email body
                        if (autoApprovedEngineers.Any(s => mail.Body.Contains(s)))
                        {  // approve jits in Dynamics



                            //Get from email Body a substring containing the msdfm_jitaccessapprovalrequest Guid
                            //eg.: msdfm_jitaccessapprovalrequest%26id%3Dadfc1808-53a2-ed11-aad1-000d3a18ba24
                            int msdfm_jitaccessapprovalrequestIndexOf = mail.Body.IndexOf("msdfm_jitaccessapprovalrequest");
                            string jitAccessApprovalRequestUrl = mail.Body.Substring(msdfm_jitaccessapprovalrequestIndexOf, 74);

                            // Regular Expression to get Guid from the previous substring
                            string regExpGuid = "[({]?[a-fA-F0-9]{8}[-]?([a-fA-F0-9]{4}[-]?){3}[a-fA-F0-9]{12}[})]?";
                            string jitAccessApprovalRequestGuid = Regex.Match(jitAccessApprovalRequestUrl, regExpGuid).Value;

                            if (string.IsNullOrEmpty(jitAccessApprovalRequestGuid))
                            {
                                //Error handling.
                                throw new Exception("Error: something went wrong, application didn't find in email body the jitAccessApprovalRequest Guid.");
                            }

                            //onesupport.crm.dynamics.com or eudfm.crm4.dynamics.com?
                            if (mail.Body.Contains(dfmUrl))
                            {
                                string connectionString = ConfigurationManager.ConnectionStrings["DfM"].ConnectionString; //app.config
                                url = Helpers.GetParameterValueFromConnectionString(connectionString, "Url");

                            }
                            else if (mail.Body.Contains(eudfmUrl))
                            {
                                string connectionString = ConfigurationManager.ConnectionStrings["eudfm"].ConnectionString; //app.config
                                url = Helpers.GetParameterValueFromConnectionString(connectionString, "Url");
                            }
                            else
                            {
                                //Error handling.
                                throw new Exception("Error: something went wrong, application didn't find in email body either EU DfM or DfM url.");
                            }



                            // append to log file
                            appendLog += "===================================================================================================================" + Environment.NewLine;
                            appendLog += DateTime.UtcNow.ToString() + " UTC: " + "Starting execution for jitAccessApprovalRequest Id " + jitAccessApprovalRequestGuid + Environment.NewLine;


                            //======================
                            // CRM Authentication 
                            // https://learn.microsoft.com/en-us/power-apps/developer/data-platform/authenticate-oauth
                            //======================

                            //Establish CRM connection
                            using (HttpClient client = Helpers.GetHttpClient(url, username, password, clientId, redirectUrl, version))
                            {

                                appendLog += DateTime.UtcNow.ToString() + " UTC: " + "successfully connected to CRM: " + url + Environment.NewLine;

                                // Run web api requests to CRM
                                // https://learn.microsoft.com/en-us/dotnet/api/system.net.http.httpclient.getasync?view=net-7.0


                                // Get request - check if it is already approved

                                string getRequest = "msdfm_jitaccessapprovalrequests(" + jitAccessApprovalRequestGuid + ")";
                                var responseGet = client.GetAsync(getRequest).Result;
                                if (responseGet.IsSuccessStatusCode)
                                {
                                    appendLog += DateTime.UtcNow.ToString() + " UTC: " + "successfully executed Get Request: "
                                        + getRequest + " " + responseGet.ReasonPhrase + Environment.NewLine;
                                    JObject responseBody = JObject.Parse(responseGet.Content.ReadAsStringAsync().Result);
                                    string statuscode = (string)responseBody["statuscode"]; // 2 - approved

                                    // is it already approved?
                                    if (statuscode != "2") // still requires approval
                                    {
                                        //  jit approval action Post request

                                        string postRequest = "msdfm_ResolveJitAccessRequest";
                                        StringContent payload = new StringContent("{\"RequestId\":\"" + jitAccessApprovalRequestGuid + "\",\"Resolution\": 2}", Encoding.UTF8, "application/json"); // statuscode=2 is approved


                                        var responsePost = client.PostAsync(postRequest, payload).Result;

                                        if (responsePost.IsSuccessStatusCode)
                                        {
                                            appendLog += DateTime.UtcNow.ToString() + " UTC: " + "successfully executed msdfm_ResolveJitAccessRequest post request: " + responsePost.ReasonPhrase + Environment.NewLine;
                                        }
                                        else
                                        {
                                            appendLog += DateTime.UtcNow.ToString() + " UTC: " + "The msdfm_ResolveJitAccessRequest post request failed with a status of " + responsePost.ReasonPhrase + Environment.NewLine;
                                        }

                                        // Get request - for log propose

                                        responseGet.Dispose();
                                        responseGet = client.GetAsync(getRequest).Result;

                                        if (responseGet.IsSuccessStatusCode)
                                        {
                                            //Get the response content and parse it.
                                            JObject body = JObject.Parse(responseGet.Content.ReadAsStringAsync().Result);
                                            string urlGetRequest = url + "/api/data/v9.2/msdfm_jitaccessapprovalrequests(" + (Guid)body["msdfm_jitaccessapprovalrequestid"] + ")";
                                            string caseNumber = (string)body["msdfm_casenumber"];
                                            string requestor = (string)body["_msdfm_requestor_value"];
                                            string createdon = (string)body["createdon"];
                                            string approver = (string)body["_modifiedby_value"]; // who approved
                                            string modifiedon = (string)body["modifiedon"]; // when it was approved
                                            string status = (string)body["statuscode"]; // 2 - approved

                                            appendLog += DateTime.UtcNow.ToString() + " UTC: " + "Get Request after approve action: " + urlGetRequest + Environment.NewLine
                                                      + "Case number: " + caseNumber + Environment.NewLine
                                                      + "Requestor: " + requestor + Environment.NewLine
                                                      + "Created on: " + createdon + Environment.NewLine
                                                      + "Approver: " + approver + Environment.NewLine
                                                      + "Approved on: " + modifiedon + Environment.NewLine
                                                      + "Status: " + status + Environment.NewLine;
                                        }
                                        else // get request for log propose failed
                                        {
                                            appendLog += DateTime.UtcNow.ToString() + " UTC: " + "The Get request to CRM failed with a status of " + responseGet.ReasonPhrase + Environment.NewLine;
                                        }
                                    }
                                    else // it was already approved by someone else (statuscode=2)
                                    {

                                        string otherApprover = (string)responseBody["_modifiedby_value"];
                                        string previousApprovedOn = (string)responseBody["modifiedon"];
                                        appendLog += DateTime.UtcNow.ToString() + " UTC: " + "DfM Jit was already approved by " + otherApprover + " on " + previousApprovedOn + Environment.NewLine;
                                    }

                                }
                                else // first get request, to get statuscode, failed 
                                {
                                    appendLog += DateTime.UtcNow.ToString() + " UTC: " + "Get request " +
                                        url + @"/api/data/v9.2/msdfm_jitaccessapprovalrequests(" + jitAccessApprovalRequestGuid + ") " +
                                        "failed with status of " + responseGet.ReasonPhrase + Environment.NewLine;
                                }

                                File.AppendAllText(logFile, appendLog);

                            }

                        };
                    }
                }

            }
            catch (Exception ex)
            {
                appendLog += DateTime.UtcNow.ToString() + " UTC: " + "failed with exception: " + ex.ToString() + Environment.NewLine;
                File.AppendAllText(logFile, appendLog);
            }

        }
        #endregion



        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
            // Note: Outlook no longer raises this event. If you have code that 
            //    must run when Outlook shuts down, see https://go.microsoft.com/fwlink/?LinkId=506785
        }



        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }

        #endregion
    }
}