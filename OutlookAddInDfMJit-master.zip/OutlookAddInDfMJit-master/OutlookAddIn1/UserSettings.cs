﻿namespace OutlookAddIn1
{
    public class UserSettings
    {
        private string _folder;
        public string Folder
        {
            get { return _folder; }
            set { _folder = value; }
        }

        private string _username;
        public string Username
        {
            get { return _username; }
            set { _username = value; }
        }

        private string _autoApprovedEngineers;
        public string AutoApprovedEngineers
        {
            get { return _autoApprovedEngineers; }
            set { _autoApprovedEngineers = value; }
        }

        private string _subjectFilter;

        public string SubjectFilter
        {
            get { return _subjectFilter; }  
            set { _subjectFilter = value; } 
        }

        private string _senderFilter;   

        public string SenderFilter
        {
            get { return _senderFilter; }   
            set { _senderFilter = value; }  
        }
      
                    

    }


}
